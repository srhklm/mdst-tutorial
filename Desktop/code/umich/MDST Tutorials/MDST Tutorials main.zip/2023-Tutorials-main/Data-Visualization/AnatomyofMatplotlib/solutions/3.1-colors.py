t = np.arange(0.0, 5.0, 0.2)
plt.plot(t, t, 'r', t, t**2, 'cyan', t, t**3, '0.7')
plt.show()
